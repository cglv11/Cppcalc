#pragma once

enum Exception {
  UnrecognizedToken, //Token in object file not recognized
  ParseError
};


